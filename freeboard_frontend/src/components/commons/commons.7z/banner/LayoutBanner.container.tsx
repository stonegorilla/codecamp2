import LayoutBannerUI from "./LayoutBanner.presenter";

export default function LayoutNavigation(props) {
  return <LayoutBannerUI best={props.best} />;
}
