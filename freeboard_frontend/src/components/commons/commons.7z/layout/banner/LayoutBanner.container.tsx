import LayoutBannerUI from "./LayoutBanner.presenter";

export default function LayoutNavigation() {
  return <LayoutBannerUI />;
}
